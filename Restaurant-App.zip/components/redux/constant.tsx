export const Add_To_Cart = "add_to_cart"

export const Remove_Form_Cart = "remove_from_cart"

export const Clear_Cart = "clear_cart"