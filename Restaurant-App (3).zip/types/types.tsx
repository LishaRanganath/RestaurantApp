export interface MenuProp {
    name: string;
    price: string;
    image: any;
}

export interface NavigationProps{
    navigation: any;
}

export interface NavigationProps {
    navigation: any; 
  }